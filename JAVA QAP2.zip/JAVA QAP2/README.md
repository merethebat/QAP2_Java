1. How many hours did it take you to complete this assessment? (Please keep try to keep track of how many hours you have spent working on each individual part of this assessment as best you can - an estimation is fine; we just want a rough idea.)
- I'd say it took me around 80 plus hours completing this assesment.

2. What online resources you have used? (My lectures, YouTube, Stack overflow etc.)
- I used Youtube, some of the lectures, w3 school, stack overflow for figuring out how to fix the classpath of my project, and mostly google.

3. Did you need to ask any of your friends in solving the problems. (If yes, please mention name of the friend. They must be amongst your class fellows.)
- none

4. Did you need to ask questions to any of your instructors? If so, how many questions did you ask (or how many help sessions did you require)?
-No, I didn't get to because I was trying to see if I could figure it out on time.

5. Rate (subjectively) the difficulty of each question from your own perspective, and whether you feel confident that you can solve a similar but different problem requiring some of the same techniques in the future now that you’ve completed this one.
- I'd rate this a 7, I did have a hard time trying to figure out Task 4.
