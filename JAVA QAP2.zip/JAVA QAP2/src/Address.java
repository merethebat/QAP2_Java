public class Address {
    private String street;
    private String city;
    private String state;
    private String zip;

    public Address(String street, String city, String state, String zip) {
        this.street = (street == null ? "" : street);
        this.city = (city == null ? "" : city);
        this.state = (state == null ? "" : state);
        this.zip = (zip == null ? "" : zip);
    }

    // Copy constructor (useful)
    public Address(Address other) {
        if (other == null) {
            this.street = "";
            this.city = "";
            this.state = "";
            this.zip = "";
        } else {
            this.street = other.street;
            this.city = other.city;
            this.state = other.state;
            this.zip = other.zip;
        }
    }

    @Override
    public String toString() {
        // Two-line format used in assignment sample:
        // "237J Harvey Hall, Menomonie, WI
        // 54751"
        return String.format("%s, %s, %s\n%s", street, city, state, zip);
    }
}
