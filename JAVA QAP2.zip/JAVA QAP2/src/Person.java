
public class Person {

    private String firstName;
    private String lastName;
    private Address home;

    public Person(String firstName, String lastName, Address home) {
        this.firstName = (firstName == null ? "" : firstName);
        this.lastName = (lastName == null ? "" : lastName);
        // store reference to Address (aggregation)
        this.home = (home == null ? new Address("", "", "", "") : home);
    }

    // Optional copy constructor
    public Person(Person other) {
        if (other == null) {
            this.firstName = "";
            this.lastName = "";
            this.home = new Address("", "", "", "");
        } else {
            this.firstName = other.firstName;
            this.lastName = other.lastName;
            this.home = new Address(other.home);
        }
    }

    @Override
    public String toString() {
        // Example from assignment: "Diane Christie, 237J Harvey Hall, Menomonie, WI\n54751"
        return String.format("%s %s, %s", firstName, lastName, home.toString());
    }

}
