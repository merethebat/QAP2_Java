public class MyRectangle {
    private MyPoint topLeft;
    private MyPoint bottomRight;

    public MyRectangle(MyPoint topLeft, MyPoint bottomRight) {
        this.topLeft = new MyPoint(topLeft);
        this.bottomRight = new MyPoint(bottomRight);
    }

    public MyRectangle(double left, double top, double right, double bottom) {
        this.topLeft = new MyPoint(left, top);
        this.bottomRight = new MyPoint(right, bottom);
    }

    public MyPoint getTopLeft() { return new MyPoint(topLeft); }
    public MyPoint getBottomRight() { return new MyPoint(bottomRight); }

    public double getWidth() { return Math.abs(bottomRight.getX() - topLeft.getX()); }
    public double getHeight() { return Math.abs(bottomRight.getY() - topLeft.getY()); }
    public double getArea() { return getWidth() * getHeight(); }

    public MyPoint getCenter() {
        double cx = (topLeft.getX() + bottomRight.getX()) / 2.0;
        double cy = (topLeft.getY() + bottomRight.getY()) / 2.0;
        return new MyPoint(cx, cy);
    }

    @Override
    public String toString() {
        return String.format("MyRectangle[topLeft=%s, bottomRight=%s]", topLeft.toString(), bottomRight.toString());
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof MyRectangle)) return false;
        MyRectangle r = (MyRectangle) obj;
        return this.topLeft.equals(r.topLeft) && this.bottomRight.equals(r.bottomRight);
    }
}
