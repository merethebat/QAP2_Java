import java.util.ArrayList;
import java.util.List;

public class CampusMap {
    private List<MyLine> walkways;
    private List<MyRectangle> buildings;
    private List<MyCirlcle> fountains;

    public CampusMap() {
        this.walkways = new ArrayList<>();
        this.buildings = new ArrayList<>();
        this.fountains = new ArrayList<>();
    }

    public void addBuilding(MyRectangle building) {
        buildings.add(building);
    }

    public void addWalkway(MyRectangle from, MyRectangle to) {
        if (!buildings.contains(from) || !buildings.contains(to)) {
            System.out.println("Error: one (or both) buildings are not in the campus map.");
            return;
        }
        MyPoint a = from.getCenter();
        MyPoint b = to.getCenter();
        walkways.add(new MyLine(a, b));
    }

    public void addFountain(MyCirlcle fountain) {
        fountains.add(fountain);
    }

    public double calculateTotalWalkwayLength() {
        double total = 0.0;
        for (MyLine l : walkways) total += l.getLength();
        return total;
    }

    public double calculateTotalFountainArea() {
        double total = 0.0;
        for (MyCirlcle c : fountains) total += c.getArea();
        return total;
    }

    public boolean isWalkwayFromTo(MyRectangle fromBuilding, MyRectangle toBuilding) {
        if (!buildings.contains(fromBuilding) || !buildings.contains(toBuilding)) return false;
        MyPoint a = fromBuilding.getCenter();
        MyPoint b = toBuilding.getCenter();
        for (MyLine l : walkways) {
            MyPoint p = l.getBegin();
            MyPoint q = l.getEnd();
            if ((p.equals(a) && q.equals(b)) || (p.equals(b) && q.equals(a))) return true;
        }
        return false;
    }

    // Utility for demonstration
    public void printSummary() {
        System.out.println("CampusMap Summary:");
        System.out.println("Buildings: " + buildings.size());
        for (MyRectangle r : buildings) System.out.println("  " + r);
        System.out.println("Fountains: " + fountains.size());
        for (MyCirlcle c : fountains) System.out.println("  " + c);
        System.out.println("Walkways: " + walkways.size());
        for (MyLine l : walkways) System.out.printf("  %s length=%.2f%n", l, l.getLength());
    }
}
