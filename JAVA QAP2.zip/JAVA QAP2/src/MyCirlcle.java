public class MyCirlcle {
    private MyPoint center;
    private double radius;

    public MyCirlcle(MyPoint center, double radius) {
        this.center = new MyPoint(center);
        this.radius = radius;
    }

    public MyPoint getCenter() { return new MyPoint(center); }
    public double getRadius() { return radius; }

    public double getArea() { return Math.PI * radius * radius; }

    @Override
    public String toString() {
        return String.format("MyCircle[center=%s, r=%.2f]", center.toString(), radius);
    }
}
