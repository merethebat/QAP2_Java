public class Money {
    private int dollars;
    private int cents;

    //constructor 
    public Money(int dollars, int cents) {
        this.dollars = dollars;
        this.cents = cents;
    }

    // Copy constructor 
    /**
     * Constructs a new Money object as a copy of the specified Money object.
     * Money object copy.
     * @param balance 
     */
    public Money(double balance) {
        Object other;
        // Copy the value of each instance variable from the parameter object
        this.dollars = other.getDollars;
        this.cents = other.getCents;
    }

    public Money(Money creditLimit) {
        
    }

    // Getters, setters, and other methods 
    public int getDollars() {
        return dollars;
    }

    public int getCents() {
        return cents;
    }

    @Override
    public String toString() {
        return "$" + dollars + "." + (cents < 10 ? "0" : "") + cents;
    }

    // Example usage in a main method
    public static void main(String[] args) {
        // Create an original Money object
        Money original = new Money(50, 25);
        System.out.println("Original money: " + original);

        // Use the copy constructor to create a duplicate
        Money duplicate = new Money(original);
        System.out.println("Duplicate money: " + duplicate);

        // Verify they are separate objects by changing the duplicate
        duplicate.dollars = 100; 
        System.out.println("Original after duplicate change: " + original); // Original remains unchanged
        System.out.println("Duplicate after change: " + duplicate);         // Duplicate has new value
    }

    public Money add(Money amount) {
        
        throw new UnsupportedOperationException("Unimplemented method 'add'");
    }

    public int compareTo(Money creditLimit) {
     
        throw new UnsupportedOperationException("Unimplemented method 'compareTo'");
    }

    public void increase(Money amount) {
        
        throw new UnsupportedOperationException("Unimplemented method 'increase'");
    }
}

