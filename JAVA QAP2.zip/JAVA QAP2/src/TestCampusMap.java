public class TestCampusMap {
    public static void main(String[] args) {
        CampusMap map = new CampusMap();

        // Buildings
        MyRectangle scienceHall = new MyRectangle(400, 400, 600, 600);
        MyRectangle library = new MyRectangle(700, 100, 900, 300);
        MyRectangle lecture1 = new MyRectangle(100, 100, 150, 150);
        MyRectangle lecture2 = new MyRectangle(160, 100, 210, 150);
        MyRectangle lecture3 = new MyRectangle(100, 160, 150, 210);
        MyRectangle lecture4 = new MyRectangle(160, 160, 210, 210);
        MyRectangle lecture5 = new MyRectangle(220, 130, 270, 180);

        // Add buildings
        map.addBuilding(scienceHall);
        map.addBuilding(library);
        map.addBuilding(lecture1);
        map.addBuilding(lecture2);
        map.addBuilding(lecture3);
        map.addBuilding(lecture4);
        map.addBuilding(lecture5);

        // Fountain
        MyCirlcle fountain = new MyCirlcle(new MyPoint(500, 500), 30);
        map.addFountain(fountain);

        // Add walkways (connect centers)
        map.addWalkway(scienceHall, library);
        map.addWalkway(scienceHall, lecture1);
        map.addWalkway(scienceHall, lecture2);
        map.addWalkway(scienceHall, lecture3);
        map.addWalkway(scienceHall, lecture4);
        map.addWalkway(scienceHall, lecture5);
        map.addWalkway(library, lecture1);
        map.addWalkway(lecture1, lecture2);
        map.addWalkway(lecture2, lecture3);

        // To connect the fountain center, create a degenerate rectangle at fountain center and add it
        MyRectangle fountainPointRect = new MyRectangle(fountain.getCenter(), fountain.getCenter());
        map.addBuilding(fountainPointRect);
        map.addWalkway(scienceHall, fountainPointRect);
        map.addWalkway(library, fountainPointRect);
        map.addWalkway(lecture5, fountainPointRect);

        // Output summary and totals
        map.printSummary();
        System.out.printf("Total walkway length: %.2f%n", map.calculateTotalWalkwayLength());
        System.out.printf("Total fountain area: %.2f%n", map.calculateTotalFountainArea());

        System.out.println("Is walkway between Science Hall and Library? " + map.isWalkwayFromTo(scienceHall, library));
        System.out.println("Is walkway between Library and Lecture5? " + map.isWalkwayFromTo(library, lecture5));
    }
}
