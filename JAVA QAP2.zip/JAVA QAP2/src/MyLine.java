public class MyLine {
    private MyPoint begin;
    private MyPoint end;

    /** Constructing a line from coordinate pairs. */
    public MyLine(int x1, int y1, int x2, int y2) {
        this.begin = new MyPoint(x1, y1);
        this.end = new MyPoint(x2, y2);
    }

    /** Construct a line from two MyPoint objects. */
    public MyLine(MyPoint begin, MyPoint end) {
        this.begin = (begin == null) ? new MyPoint() : new MyPoint(begin);
        this.end   = (end == null)   ? new MyPoint() : new MyPoint(end);
    }

    /** Return copy of the begin point*/
    public MyPoint getBegin() {
        return new MyPoint(begin);
    }

    /** Set begin point*/
    public void setBegin(MyPoint begin) {
        this.begin = (begin == null) ? new MyPoint() : new MyPoint(begin);
    }

    /** Return copy of the end point */
    public MyPoint getEnd() {
        return new MyPoint(end);
    }

    /** Set end point */
    public void setEnd(MyPoint end) {
        this.end = (end == null) ? new MyPoint() : new MyPoint(end);
    }

    // Begin X/Y accessors/mutators
    public int getBeginX() {
        return begin.getX();
    }

    public void setBeginX(int x) {
        begin.setX(x);
    }

    public int getBeginY() {
        return begin.getY();
    }

    public void setBeginY(int y) {
        begin.setY(y);
    }

    // End X/Y accessors/mutators
    public int getEndX() {
        return end.getX();
    }

    public void setEndX(int x) {
        end.setX(x);
    }

    public int getEndY() {
        return end.getY();
    }

    public void setEndY(int y) {
        end.setY(y);
    }

    // Begin XY and End XY
    public int[] getBeginXY() {
        return begin.getXY();
    }

    public void setBeginXY(int x, int y) {
        begin.setLocation(x, y);
    }

    public int[] getEndXY() {
        return end.getXY();
    }

    public void setEndXY(int x, int y) {
        end.setLocation(x, y);
    }

    /** Length of line: uses MyPoint.distance(). */
    public double getLength() {
        return begin.distance(end);
    }

    /**
     * Return the gradient (angle) in radians.
     * Use Math.atan2(yDiff, xDiff) where yDiff = (endY - beginY).
     */
    public double getGradient() {
        int yDiff = getEndY() - getBeginY();
        int xDiff = getEndX() - getBeginX();
        return Math.atan2(yDiff, xDiff);
    }

    @Override
    public String toString() {
        return String.format("MyLine[begin=(%d,%d),end=(%d,%d)]",
                getBeginX(), getBeginY(), getEndX(), getEndY());
    }
}
