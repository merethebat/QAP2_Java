public class TestMyLine {
    public static void main(String[] args) {
        System.out.println("=== TestMyLine: constructor from coords ===");
        MyLine line1 = new MyLine(0, 0, 3, 4); // classic 3-4-5 triangle
        System.out.println("line1: " + line1);
        System.out.println("Begin (copy): " + line1.getBegin());
        System.out.println("End (copy): " + line1.getEnd());
        System.out.printf("Length (expected 5.00): %.2f%n", line1.getLength());
        System.out.printf("Gradient (radians, expected ~0.9273): %.4f%n", line1.getGradient());

        System.out.println("\n=== TestMyLine: constructor from MyPoint ===");
        MyPoint a = new MyPoint(10, 10);
        MyPoint b = new MyPoint(13, 14);
        MyLine line2 = new MyLine(a, b);
        System.out.println("line2: " + line2);
        System.out.printf("Length (expected 5.00): %.2f%n", line2.getLength());

        System.out.println("\n=== Test setters/getters ===");
        line2.setBeginX(0);
        line2.setBeginY(0);
        System.out.println("After setBeginX/Y -> " + line2);
        System.out.println("getBeginX: " + line2.getBeginX() + ", getBeginY: " + line2.getBeginY());

        line2.setEndX(6);
        line2.setEndY(8);
        System.out.println("After setEndX/Y -> " + line2);
        System.out.printf("Length (expected 10.00): %.2f%n", line2.getLength());

        System.out.println("\n=== Test getBeginXY / setBeginXY / getEndXY / setEndXY ===");
        int[] beginXY = line2.getBeginXY();
        int[] endXY = line2.getEndXY();
        System.out.println("BeginXY: (" + beginXY[0] + "," + beginXY[1] + ")");
        System.out.println("EndXY: (" + endXY[0] + "," + endXY[1] + ")");

        line2.setBeginXY(1, 1);
        line2.setEndXY(4, 5);
        System.out.println("After setBeginXY(1,1) and setEndXY(4,5): " + line2);
        System.out.printf("Length (expected 5.00): %.2f%n", line2.getLength());
        System.out.printf("Gradient (radians): %.4f%n", line2.getGradient());

        System.out.println("\n=== Defensive copy checks ===");
        MyPoint p = line2.getBegin();
        System.out.println("Begin point copy: " + p);
        p.setLocation(999, 999); // should not modify internal begin of line2
        System.out.println("Modified copy to (999,999). line2 begin still: " + line2.getBegin());

        System.out.println("\nAll public methods tested.");
    }
}
