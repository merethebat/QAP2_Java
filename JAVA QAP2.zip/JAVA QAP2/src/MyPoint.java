public class MyPoint {
    private int x;
    private int y;

    /** No-arg constructor sets point to (0,0). 
     * @param cy 
     * @param cx */
    public MyPoint(double cx, double cy) {
        this(0, 0);
    }

    /** Construct point at (x, y). */
    public MyPoint(int x, int y) {
        this.x = x;
        this.y = y;
    }

    /** Copy constructor. */
    public MyPoint(MyPoint other) {
        if (other == null) {
            this.x = 0;
            this.y = 0;
        } else {
            this.x = other.x;
            this.y = other.y;
        }
    }

    public MyPoint() {
       
    }

    /** Getter for x. */
    public int getX() {
        return x;
    }

    /** Getter for y. */
    public int getY() {
        return y;
    }

    /** Setter for x. */
    public void setX(int x) {
        this.x = x;
    }

    /** Setter for y. */
    public void setY(int y) {
        this.y = y;
    }

    /** Set both coordinates. */
    public void setLocation(int x, int y) {
        this.x = x;
        this.y = y;
    }

    /** Return distance from this point to other (uses hypot for accuracy). */
    public double distance(MyPoint other) {
        if (other == null) return Math.hypot(this.x, this.y);
        double dx = this.x - other.x;
        double dy = this.y - other.y;
        return Math.hypot(dx, dy);
    }

    /** Return a two-element array [x, y] (defensive copy). */
    public int[] getXY() {
        return new int[] { x, y };
    }

    @Override
    public String toString() {
        return "(" + x + "," + y + ")";
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof MyPoint)) return false;
        MyPoint p = (MyPoint) obj;
        return this.x == p.x && this.y == p.y;
    }
}
