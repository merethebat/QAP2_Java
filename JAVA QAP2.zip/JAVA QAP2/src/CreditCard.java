public class CreditCard {
    private Person owner;
    private Money balance;
    private Money creditLimit;

    public CreditCard(Person owner, Money creditLimit){
        this.owner = owner;
        this.creditLimit = creditLimit == null ? new Money(creditLimit) : new Money(creditLimit);
        this.balance = new Money(0, 0);
    }

    // Getters
    public Money getBalance(){
        return new Money(balance);
    }

    //credit limit
    public Money getCreditLimit(){
        return new Money(creditLimit);
    }

    public String getPersonals(){
        return owner == null ? "": owner.toString();
    }

    //when charge is acccepted is when you'd print it
    public void charge(Money amount) {
        if (amount == null) return;
        Money prospective = balance.add(amount);
        if (prospective.compareTo(creditLimit) <= 0) {
            balance.increase(amount);
            System.out.println("Charge: " + amount.toString());
        } else {
            System.out.println("Exceeds credit limit");
        }
    }

    //Make payment subtract from the balance and print from the payment line.
    public void payment(Money amount) {
        if (amount == null) return;
        balance.increase(amount);
        System.out.println("Payment: " + amount.toString());
    }


}
