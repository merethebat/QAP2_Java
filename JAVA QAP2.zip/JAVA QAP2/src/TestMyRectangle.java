public class TestMyRectangle {
    public static void main(String[] args) {
        MyRectangle rect = new MyRectangle(new MyPoint(0, 0), new MyPoint(10, 5));
        System.out.println("Rectangle: " + rect);
        System.out.printf("Width: %.2f, Height: %.2f, Area: %.2f%n",
                rect.getWidth(), rect.getHeight(), rect.getArea());
        System.out.println("Center: " + rect.getCenter());
    }
}
